//
//  VidcoinRewardedVideoCustomEvent.m
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import "VidcoinRewardedVideoCustomEvent.h"
#import "MPVidcoinRouter.h"
#import "VidcoinInstanceMediationSettings.h"


static NSString *const kMPVidcoinAppId = @"appId";
static NSString *const kMPVidcoinPlacementCode = @"placementCode";
static NSString *const kMPVidcoinZoneId = @"zoneId";

@interface VidcoinRewardedVideoCustomEvent () <MPVidcoinRouterDelegate>
@property (nonatomic, weak) NSString* placementCode;
@end

@implementation VidcoinRewardedVideoCustomEvent

#pragma mark - MPRewardedVideoCustomEvent

- (void)requestRewardedVideoWithCustomEventInfo:(NSDictionary *)info {
    [VidCoin setGDRPApplicable:[[MoPub sharedInstance] isGDPRApplicable]];
    if ([[MoPub sharedInstance] isGDPRApplicable] == MPBoolYes) {
        BOOL canCollectPersonnalInfo = [[MoPub sharedInstance] canCollectPersonalInfo];
        [VidCoin setUserConsent:canCollectPersonnalInfo];
    }

    NSString *appId = [info objectForKey:kMPVidcoinAppId];
    NSString *zoneId = [info objectForKey:kMPVidcoinZoneId];
    _placementCode = [info objectForKey:kMPVidcoinPlacementCode];
    
    VidcoinInstanceMediationSettings *instanceSettings = [self.delegate instanceMediationSettingsForClass:[VidcoinInstanceMediationSettings class]];
    VidcoinInstanceMediationSettings *globalSettings = [[MoPub sharedInstance] globalMediationSettingsForClass:[VidcoinInstanceMediationSettings class]];
    if (instanceSettings != nil) {
        [[MPVidcoinRouter sharedRouter] requestAdsWithAppId:appId zoneId:zoneId placementCode:_placementCode delegate:self settings:instanceSettings];
    } else if (globalSettings != nil) {
        [[MPVidcoinRouter sharedRouter] requestAdsWithAppId:appId zoneId:zoneId placementCode:_placementCode delegate:self settings:globalSettings];
    } else {
        [[MPVidcoinRouter sharedRouter] requestAdsWithAppId:appId zoneId:zoneId placementCode:_placementCode delegate:self settings:nil];
    }
}

- (BOOL)hasAdAvailable {
    return [[MPVidcoinRouter sharedRouter] adAvailable:_placementCode];
}

- (void)presentRewardedVideoFromViewController:(UIViewController *)viewController {
    [[MPVidcoinRouter sharedRouter] presentRewardedVideoAdFromViewController:viewController placementCode:_placementCode];
}

#pragma mark - MPVidcoinRouterDelegate
- (void)vidcoinDidLoadAdForCustomEvent {
    [self.delegate rewardedVideoDidLoadAdForCustomEvent:self];
}

- (void)vidcoinDidFailToLoadAdForCustomEvent:(NSError *)error {
    [self.delegate rewardedVideoDidFailToLoadAdForCustomEvent:self error:error];
}

- (void)vidcoinDidFailToPlayForCustomEvent:(NSError *)error {
    [self.delegate rewardedVideoDidFailToPlayForCustomEvent:self error:error];
}

- (void)vidcoinWillAppearForCustomEvent {
    [self.delegate rewardedVideoWillAppearForCustomEvent:self];
}

- (void)vidcoinDidAppearForCustomEvent {
    [self.delegate rewardedVideoDidAppearForCustomEvent:self];
}

- (void)vidcoinWillDisappearForCustomEvent {
    [self.delegate rewardedVideoWillDisappearForCustomEvent:self];
}

- (void)vidcoinDidDisappearForCustomEvent {
    [self.delegate rewardedVideoDidDisappearForCustomEvent:self];
}

/* Handling tap event on storeView */
- (void)vidcoinDidReceiveTapEvent{
    [self.delegate rewardedVideoDidReceiveTapEventForCustomEvent:self];
}

- (void)vidcoinShouldRewardUserForCustomEvent:(NSNumber *)reward {
    NSString *currencyType = kMPRewardedVideoRewardCurrencyTypeUnspecified;
    MPRewardedVideoReward *videoReward = [[MPRewardedVideoReward alloc] initWithCurrencyType:currencyType amount:reward];
    [self.delegate rewardedVideoShouldRewardUserForCustomEvent:self reward:videoReward];
}

@end
