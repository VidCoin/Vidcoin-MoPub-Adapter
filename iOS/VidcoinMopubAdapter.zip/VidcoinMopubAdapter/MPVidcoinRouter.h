//
//  MPVidcoinRouter.h
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <VidCoin/VidCoin.h>

@protocol MPVidcoinRouterDelegate;
@class VidcoinInstanceMediationSettings;

@interface MPVidcoinRouter : NSObject <VidCoinDelegate>

+ (MPVidcoinRouter *)sharedRouter;

- (void)requestAdWithPlacementFormat:(VAPlacementFormat)placementFormat
                              zoneId:(NSString *)zoneId
                            delegate:(id<MPVidcoinRouterDelegate>)delegate
                            settings:(VidcoinInstanceMediationSettings *)settings;
- (BOOL)isAdAvailable:(VAPlacementFormat)placementFormat;
- (void)presentRewardedVideoAdFromViewController:(UIViewController *)viewController;
- (void)presentInterstitialAdFromViewController:(UIViewController *)viewController;

@end

@protocol MPVidcoinRouterDelegate <NSObject>
@required

- (void)vidcoinDidLoadAdForCustomEvent;
- (void)vidcoinDidFailToLoadAdForCustomEvent:(NSError *)error;
- (void)vidcoinDidFailToPlayForCustomEvent:(NSError *)error;
- (void)vidcoinWillAppearForCustomEvent;
- (void)vidcoinDidAppearForCustomEvent;
- (void)vidcoinWillDisappearForCustomEvent;
- (void)vidcoinDidDisappearForCustomEvent;
- (void)vidcoinDidReceiveTapEvent;

@optional
- (void)vidcoinShouldRewardUserForCustomEvent:(NSNumber *)reward;
@end
