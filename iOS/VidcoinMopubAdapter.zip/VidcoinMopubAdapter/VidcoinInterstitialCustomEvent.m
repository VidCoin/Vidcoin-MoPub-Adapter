//
//  VidcoinInterstitialCustomEvent.m
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import "VidcoinInterstitialCustomEvent.h"
#import "MPVidcoinRouter.h"
#import "VidcoinInstanceMediationSettings.h"

static NSString *const kMPVidcoinAppId = @"appId";
static NSString *const kMPVidcoinPlacementCode = @"placementCode";
static NSString *const kMPVidcoinZoneId = @"zoneId";

@interface VidcoinInterstitialCustomEvent () <MPVidcoinRouterDelegate>

@property (nonatomic, assign) BOOL handledAdAvailable;
@property (nonatomic, weak) NSString *placementCode;

@end


@implementation VidcoinInterstitialCustomEvent

-(void)requestInterstitialWithCustomEventInfo:(NSDictionary *)info {
    [VidCoin setGDRPApplicable:[[MoPub sharedInstance] isGDPRApplicable]];
    if ([[MoPub sharedInstance] isGDPRApplicable] == MPBoolYes) {
        BOOL canCollectPersonnalInfo = [[MoPub sharedInstance] canCollectPersonalInfo];
        [VidCoin setUserConsent:canCollectPersonnalInfo];
    }
    self.handledAdAvailable = NO;
    NSString *appId = [info objectForKey:kMPVidcoinAppId];
    NSString *zoneId = [info objectForKey:kMPVidcoinZoneId];
    _placementCode = [info objectForKey:kMPVidcoinPlacementCode];
    
    [[MPVidcoinRouter sharedRouter] requestAdsWithAppId:appId zoneId:zoneId placementCode:_placementCode delegate:self settings:nil];
}

-(void) showInterstitialFromRootViewController:(UIViewController *)rootViewController {
    [[MPVidcoinRouter sharedRouter] presentRewardedVideoAdFromViewController:rootViewController placementCode:_placementCode];
}

#pragma mark - MPVidcoinRouterDelegate

- (void)vidcoinDidLoadAdForCustomEvent {
    if (!self.handledAdAvailable) {
        self.handledAdAvailable = YES;
        [self.delegate interstitialCustomEvent:self didLoadAd:nil];
    }
}

- (void)vidcoinDidFailToLoadAdForCustomEvent:(NSError *)error {
    [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:error];
}

- (void)vidcoinDidFailToPlayForCustomEvent:(NSError *)error {
    [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:error];
}

- (void)vidcoinWillAppearForCustomEvent {
    [self.delegate interstitialCustomEventWillAppear:self];
}

- (void)vidcoinDidAppearForCustomEvent {
    [self.delegate interstitialCustomEventDidAppear:self];
}

- (void)vidcoinWillDisappearForCustomEvent {
    [self.delegate interstitialCustomEventWillDisappear:self];
}

- (void)vidcoinDidDisappearForCustomEvent {
    [self.delegate interstitialCustomEventDidDisappear:self];
}

@end
