//
//  VidcoinInstanceMediationSettings.h
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import <Foundation/Foundation.h>

#if __has_include(<MoPub/MoPub.h>)
    #import <MoPub/MoPub.h>
#elif __has_include(<MoPubSDKFramework/MoPub.h>)
    #import <MoPubSDKFramework/MoPub.h>
#else
    #import "MPMediationSettingsProtocol.h"
#endif

#define kVCAdapterUserGenderMale @"MALE"
#define kVCAdapterUserGenderFemale @"FEMALE"

@interface VidcoinInstanceMediationSettings : NSObject <MPMediationSettingsProtocol>

@property (nonatomic, copy) NSString* userAppId;
@property (nonatomic, copy) NSString* userBithYear;
@property (nonatomic, copy) NSString* userGender;

@end
