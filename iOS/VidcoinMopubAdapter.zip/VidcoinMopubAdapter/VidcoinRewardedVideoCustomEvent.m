//
//  VidcoinRewardedVideoCustomEvent.m
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import "VidcoinRewardedVideoCustomEvent.h"
#import "MPVidcoinRouter.h"
#import "VidcoinInstanceMediationSettings.h"


static NSString *const kMPVidcoinZoneId = @"zoneId";

@interface VidcoinRewardedVideoCustomEvent () <MPVidcoinRouterDelegate>

@end

@implementation VidcoinRewardedVideoCustomEvent

#pragma mark - MPRewardedVideoCustomEvent

- (void)requestRewardedVideoWithCustomEventInfo:(NSDictionary *)info {
    [VidCoin setGDRPApplicable:[[MoPub sharedInstance] isGDPRApplicable]];
    if ([[MoPub sharedInstance] isGDPRApplicable] == MPBoolYes) {
        BOOL canCollectPersonnalInfo = [[MoPub sharedInstance] canCollectPersonalInfo];
        [VidCoin setUserConsent:canCollectPersonnalInfo];
    }

    NSString *zoneId = [info objectForKey:kMPVidcoinZoneId];
    
    VidcoinInstanceMediationSettings *instanceSettings = [self.delegate instanceMediationSettingsForClass:[VidcoinInstanceMediationSettings class]];
    VidcoinInstanceMediationSettings *globalSettings = [[MoPub sharedInstance] globalMediationSettingsForClass:[VidcoinInstanceMediationSettings class]];
    VidcoinInstanceMediationSettings *settings;
    if (instanceSettings != nil) {
        settings = instanceSettings;
    } else if (globalSettings != nil) {
        settings = globalSettings;
    }
    
    [[MPVidcoinRouter sharedRouter] requestAdWithPlacementFormat:VAPlacementFormatRewarded zoneId:zoneId delegate:self settings:settings];
}

- (BOOL)hasAdAvailable {
    return [[MPVidcoinRouter sharedRouter] isAdAvailable:VAPlacementFormatRewarded];
}

- (void)presentRewardedVideoFromViewController:(UIViewController *)viewController {
    [[MPVidcoinRouter sharedRouter] presentRewardedVideoAdFromViewController:viewController];
}

#pragma mark - MPVidcoinRouterDelegate
- (void)vidcoinDidLoadAdForCustomEvent {
    [self.delegate rewardedVideoDidLoadAdForCustomEvent:self];
}

- (void)vidcoinDidFailToLoadAdForCustomEvent:(NSError *)error {
    [self.delegate rewardedVideoDidFailToLoadAdForCustomEvent:self error:error];
}

- (void)vidcoinDidFailToPlayForCustomEvent:(NSError *)error {
    [self.delegate rewardedVideoDidFailToPlayForCustomEvent:self error:error];
}

- (void)vidcoinWillAppearForCustomEvent {
    [self.delegate rewardedVideoWillAppearForCustomEvent:self];
}

- (void)vidcoinDidAppearForCustomEvent {
    [self.delegate rewardedVideoDidAppearForCustomEvent:self];
}

- (void)vidcoinWillDisappearForCustomEvent {
    [self.delegate rewardedVideoWillDisappearForCustomEvent:self];
}

- (void)vidcoinDidDisappearForCustomEvent {
    [self.delegate rewardedVideoDidDisappearForCustomEvent:self];
}

/* Handling tap event on storeView */
- (void)vidcoinDidReceiveTapEvent{
    [self.delegate rewardedVideoDidReceiveTapEventForCustomEvent:self];
}

- (void)vidcoinShouldRewardUserForCustomEvent:(NSNumber *)reward {
    NSString *currencyType = kMPRewardedVideoRewardCurrencyTypeUnspecified;
    MPRewardedVideoReward *videoReward = [[MPRewardedVideoReward alloc] initWithCurrencyType:currencyType amount:reward];
    [self.delegate rewardedVideoShouldRewardUserForCustomEvent:self reward:videoReward];
}

@end
