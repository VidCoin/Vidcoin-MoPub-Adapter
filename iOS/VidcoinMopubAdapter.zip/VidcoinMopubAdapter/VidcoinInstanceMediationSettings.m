//
//  VidcoinInstanceMediationSettings.m
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import "VidcoinInstanceMediationSettings.h"

@implementation VidcoinInstanceMediationSettings

@end
