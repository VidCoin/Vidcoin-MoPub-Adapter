//
//  MPVidcoinRouter.h
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <VidCoin/VidCoin.h>

@protocol MPVidcoinRouterDelegate;
@class VidcoinInstanceMediationSettings;

@interface MPVidcoinRouter : NSObject <VidCoinDelegate>

@property (nonatomic, strong) NSMutableDictionary *delegates;
@property (nonatomic, strong) NSMutableDictionary *adLoaded;

+ (MPVidcoinRouter *)sharedRouter;

- (void)requestAdsWithAppId:(NSString *)appId zoneId:(NSString *)zoneId placementCode:(NSString *)placementCode delegate:(id<MPVidcoinRouterDelegate>)delegate settings:(VidcoinInstanceMediationSettings *)settings;
- (BOOL)adAvailable:(NSString *)placementCode;
- (void)presentRewardedVideoAdFromViewController:(UIViewController *)viewController placementCode:(NSString*)placementCode;
- (void)presentInterstitialAdFromViewController:(UIViewController *)viewController placementCode:(NSString*)placementCode;

@end

@protocol MPVidcoinRouterDelegate <NSObject>
@required

- (void)vidcoinDidLoadAdForCustomEvent;
- (void)vidcoinDidFailToLoadAdForCustomEvent:(NSError *)error;
- (void)vidcoinDidFailToPlayForCustomEvent:(NSError *)error;
- (void)vidcoinWillAppearForCustomEvent;
- (void)vidcoinDidAppearForCustomEvent;
- (void)vidcoinWillDisappearForCustomEvent;
- (void)vidcoinDidDisappearForCustomEvent;
- (void)vidcoinDidReceiveTapEvent;

@optional
- (void)vidcoinShouldRewardUserForCustomEvent:(NSNumber *)reward;
@end
