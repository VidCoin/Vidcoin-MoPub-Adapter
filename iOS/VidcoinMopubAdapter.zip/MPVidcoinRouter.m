//
//  MPVidcoinRouter.m
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import "MPVidcoinRouter.h"
#import "VidcoinInstanceMediationSettings.h"

@interface MPVidcoinRouter () {
    //TODO: to be removed once the delegate calls order is fixed
    BOOL dontValidateView;
}

@property (nonatomic, strong) NSMutableDictionary *delegates;
@property (nonatomic, strong) NSMutableDictionary *loadedAds;

//TODO: This is a temporary workarround and should be remove
// once the requestAd/getCampaign timeout will managed by the sdk.
@property (nonatomic, strong) NSMutableDictionary<NSNumber *, NSNumber *> *mopubDelegateCalled;

@end

@implementation MPVidcoinRouter

#pragma mark - Public methods

+ (MPVidcoinRouter *)sharedRouter {
    static MPVidcoinRouter * sharedRouter;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedRouter = [[MPVidcoinRouter alloc] init];
    });
    return sharedRouter;
}

- (void)requestAdWithPlacementFormat:(VAPlacementFormat)placementFormat
                              zoneId:(NSString *)zoneId
                            delegate:(id<MPVidcoinRouterDelegate>)delegate
                            settings:(VidcoinInstanceMediationSettings *)settings {
    [self.delegates setObject:delegate forKey:[NSNumber numberWithInt:placementFormat]];
    
    if (settings != nil) {
        NSMutableDictionary *vidcoinDictionary = [NSMutableDictionary dictionary];
        if (settings.userAppId && ![settings.userAppId isEqualToString:@""]) {
            [vidcoinDictionary setObject:settings.userAppId forKey:kVCUserGameID];
        }
        if (settings.userBirthYear && ![settings.userBirthYear isEqualToString:@""]) {
            [vidcoinDictionary setObject:settings.userBirthYear forKey:kVCUserBirthYear];
        }
        if (settings.userGender && ![settings.userGender isEqualToString:@""]) {
            [vidcoinDictionary setObject:settings.userGender forKey:kVCUserGenderKey];
        }
        
        if (vidcoinDictionary && vidcoinDictionary.count > 0) {
            [VidCoin updateUserDictionary:[vidcoinDictionary copy]];
        }
    }
    [self.mopubDelegateCalled setObject:[NSNumber numberWithBool:NO] forKey:[NSNumber numberWithInt:placementFormat]];
    [VidCoin requestAdForPlacementFormat:placementFormat zoneId:zoneId];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self timeRanOut:placementFormat];
    });
    
}

-(void)didLoadAd:(VAPlacementFormat)placementFormat {
    [self.loadedAds setObject:@YES forKey:[NSNumber numberWithInt:placementFormat]];
    [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinDidLoadAdForCustomEvent];
}

- (void)didUnloadAd:(VAPlacementFormat)placementFormat {
    [self.loadedAds setObject:@NO forKey:[NSNumber numberWithInt:placementFormat]];
}

- (void)timeRanOut:(VAPlacementFormat)placementFormat {
    if ([[self.mopubDelegateCalled objectForKey:[NSNumber numberWithInt:placementFormat]] boolValue]) {
        return;
    }
    
    [self.mopubDelegateCalled setObject:[NSNumber numberWithBool:YES] forKey:[NSNumber numberWithInt:placementFormat]];
    
    if (![[self.loadedAds objectForKey:[NSNumber numberWithInt:placementFormat]] boolValue]) {
        [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinDidFailToLoadAdForCustomEvent:[NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorNoAdsAvailable userInfo:nil]];
    }
}

- (BOOL)isAdAvailable:(VAPlacementFormat)placementFormat {
    return [VidCoin videoIsAvailableForPlacementFormat:placementFormat];
}

- (void)presentVideoAdForPlacementFormat:(VAPlacementFormat)placementFormat inViewController:(UIViewController *)viewController withError:(NSError *)error  {
    if ([self isAdAvailable:placementFormat]) {
        [VidCoin playAdFromViewController:viewController forPlacementFormat:placementFormat animated:YES];
    } else {
        MPLogInfo(@"Failed to present Vidcoin video ad: no ad available.");
        [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinDidFailToPlayForCustomEvent:error];
    }
}

- (void)presentRewardedVideoAdFromViewController:(UIViewController *)viewController {
    VAPlacementFormat placementFormat = VAPlacementFormatRewarded;
    NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorNoAdsAvailable userInfo:nil];
    
    [self presentVideoAdForPlacementFormat:placementFormat inViewController:viewController withError:error];
}

-(void)presentInterstitialAdFromViewController:(UIViewController *)viewController {
    VAPlacementFormat placementFormat = VAPlacementFormatInterstitial;
    [self presentVideoAdForPlacementFormat:placementFormat inViewController:viewController withError:nil];
}

#pragma mark - Private methods
- (id)init {
    self = [super init];
    if (self) {
        [VidCoin setLoggingEnabled:YES];
        [VidCoin setDelegate:self];
        [VidCoin setGDRPApplicable:[[MoPub sharedInstance] isGDPRApplicable]];
        [VidCoin setUserConsent:[[MoPub sharedInstance] canCollectPersonalInfo]];
        self.delegates = [NSMutableDictionary dictionary];
        self.loadedAds = [NSMutableDictionary dictionary];
        self.mopubDelegateCalled = [NSMutableDictionary<NSNumber *, NSNumber *> new];
    }
    return self;
}

#pragma mark - VidCoinDelegate

- (void)requestAdFinishedForPlacementFormat:(VAPlacementFormat)placementFormat {
    if ([[self.mopubDelegateCalled objectForKey:[NSNumber numberWithInt:placementFormat]] boolValue]) {
        return;
    }
    
    [self.mopubDelegateCalled setObject:[NSNumber numberWithBool:YES] forKey:[NSNumber numberWithInt:placementFormat]];
    
    if ([self isAdAvailable:placementFormat]) {
        [self didLoadAd:placementFormat];
    } else {
        [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinDidFailToLoadAdForCustomEvent:[NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorNoAdsAvailable userInfo:nil]];
    }
}

- (void)vidcoinViewWillAppear:(VAPlacementFormat)placementFormat {
    [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinWillAppearForCustomEvent];
    [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinDidAppearForCustomEvent];
}

- (void)vidcoinViewDidDisappear:(VCStatusCode)status withReward:(NSInteger)reward forPlacementFormat:(VAPlacementFormat)placementFormat {
    
    //TODO: to be removed once the delegate calls order is fixed
    dontValidateView = NO;
    [self vidcoinDidValidateView:status withReward:reward forPlacementFormat:placementFormat];
    dontValidateView = YES;
    
    
    [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinWillDisappearForCustomEvent];
    [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinDidDisappearForCustomEvent];
    
    [self didUnloadAd:placementFormat];
}

- (void)vidcoinDidValidateView:(VCStatusCode)status withReward:(NSInteger)reward forPlacementFormat:(VAPlacementFormat)placementFormat {
    
    //TODO: to be removed once the delegate calls order is fixed
    if (dontValidateView) {
        return;
    }
    
    switch (status) {
        case VCStatusCodeCancel: {
            break;
        }
        case VCStatusCodeError: {
            NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorUnknown userInfo:nil];
            [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinDidFailToPlayForCustomEvent:error];
            break;
        }
        case VCStatusCodeSuccess: {
            if ([[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] respondsToSelector:@selector(vidcoinShouldRewardUserForCustomEvent:)]) {
                [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinShouldRewardUserForCustomEvent:[NSNumber numberWithInteger:reward]];
            }
            break;
        }
        default: {
            NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorUnknown userInfo:nil];
            [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinDidFailToPlayForCustomEvent:error];
            break;
        }
    }
}
- (void)vidcoinDidReceiveTapEvent:(VAPlacementFormat)placementFormat {
    [[self.delegates objectForKey:[NSNumber numberWithInt:placementFormat]] vidcoinDidReceiveTapEvent];
}

@end
