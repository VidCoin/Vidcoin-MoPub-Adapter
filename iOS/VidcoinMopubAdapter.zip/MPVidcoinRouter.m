//
//  MPVidcoinRouter.m
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import "MPVidcoinRouter.h"
#import "VidcoinInstanceMediationSettings.h"

@implementation MPVidcoinRouter {
    BOOL initialized;
    BOOL dontValidateView;
    
    NSMutableArray<NSString *> *waitingPlacementCodes;
}

#pragma mark - Public methods

+ (MPVidcoinRouter *)sharedRouter
{
    static MPVidcoinRouter * sharedRouter;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedRouter = [[MPVidcoinRouter alloc] init];
    });
    return sharedRouter;
}

- (void)requestAdsWithAppId:(NSString *)appId
                     zoneId:(NSString*)zoneId
              placementCode:(NSString *)placement
                   delegate:(id<MPVidcoinRouterDelegate>)delegate
                   settings:(VidcoinInstanceMediationSettings *)settings {
    [self.delegates setObject:delegate forKey:placement];
    
    if (settings != nil) {
        NSMutableDictionary *vidcoinDictionary = [NSMutableDictionary dictionary];
        if (settings.userAppId && ![settings.userAppId isEqualToString:@""]) {
            [vidcoinDictionary setObject:settings.userAppId forKey:kVCUserGameID];
        }
        if (settings.userBirthYear && ![settings.userBirthYear isEqualToString:@""]) {
            [vidcoinDictionary setObject:settings.userBirthYear forKey:kVCUserBirthYear];
        }
        if (settings.userGender && ![settings.userGender isEqualToString:@""]) {
            [vidcoinDictionary setObject:settings.userGender forKey:kVCUserGenderKey];
        }
        
        if (vidcoinDictionary && vidcoinDictionary.count > 0) {
            [VidCoin updateUserDictionary:[vidcoinDictionary copy]];
        }
    }
    if (!initialized) {
        [waitingPlacementCodes addObject:placement];
        [self startWithAppId:appId zoneId:zoneId];
    }
    else {
        [VidCoin requestAdForPlacement:placement zoneId:zoneId];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self timeRanOut:placement];
        });
    }

}

-(void)didLoadAd:(NSString*)placementCode {
    [self.adLoaded setObject:[NSNumber numberWithBool:YES] forKey:placementCode];
    [[self.delegates objectForKey:placementCode] vidcoinDidLoadAdForCustomEvent];
}

- (void)didUnloadAd:(NSString*)placementCode {
    [self.adLoaded setObject:[NSNumber numberWithBool:NO] forKey:placementCode];
}

- (void)timeRanOut:(NSString*)placementCode {
    if (![[self.adLoaded objectForKey:placementCode] boolValue]) {
        [[self.delegates objectForKey:placementCode] vidcoinDidFailToLoadAdForCustomEvent:[NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorNoAdsAvailable userInfo:nil]];
    }
}

- (BOOL)adAvailable:(NSString *)placementCode {
    return [VidCoin videoIsAvailableForPlacement:placementCode];
}

- (void)presentRewardedVideoAdFromViewController:(UIViewController *)viewController placementCode:(NSString *)placementCode{
    if ([self adAvailable:placementCode]) {
        [VidCoin playAdFromViewController:viewController forPlacement:placementCode animated:YES];
    } else {
        MPLogInfo(@"Failed to present Vidcoin video ad: no ad available.");
        NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorNoAdsAvailable userInfo:nil];
        [[self.delegates objectForKey:placementCode] vidcoinDidFailToPlayForCustomEvent:error];
    }
}

-(void)presentInterstitialAdFromViewController:(UIViewController *)viewController placementCode:(NSString *)placementCode{
    if ([self adAvailable:placementCode]) {
        [VidCoin playAdFromViewController:viewController forPlacement:placementCode animated:YES];
    } else {
        MPLogInfo(@"Failed to present Vidcoin video ad: no ad available.");
        [[self.delegates objectForKey:placementCode] vidcoinDidFailToPlayForCustomEvent:nil];
    }
}

#pragma mark - Private methods
- (id)init {
    self = [super init];
    if (self) {
        initialized = NO;
        self.delegates = [NSMutableDictionary dictionary];
        self.adLoaded = [NSMutableDictionary dictionary];
        waitingPlacementCodes = [NSMutableArray<NSString *> new];
    }
    return self;
}

- (void)startWithAppId:(NSString*)appId zoneId:(NSString*)zoneId{
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        BOOL hasUserConsent = [[MoPub sharedInstance] canCollectPersonalInfo];
        BOOL isGDPRApplicable = [[MoPub sharedInstance] isGDPRApplicable];
        [VidCoin startWithGameId:appId delegate:self hasUserConsent:hasUserConsent isGDPRApplicable:isGDPRApplicable zoneId:zoneId];
        [VidCoin setLoggingEnabled:YES];
    });
}

#pragma mark - VidCoinDelegate
- (void)vidcoinInitUpdate:(BOOL)status {
    
    if (status) {
        initialized = YES;
        for (NSString *placement in waitingPlacementCodes) {
            [VidCoin requestAdForPlacement:placement];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self timeRanOut:placement];
            });
        }
        
        [waitingPlacementCodes removeAllObjects];
    }
}

- (void)vidcoinCampaignsUpdate:(NSString *)placementCode {
    for (id key in self.delegates) {
        if ([self adAvailable:key])
            [self didLoadAd:key];
    }
}

- (void)vidcoinViewWillAppear:(NSString*)placementCode {
    [[self.delegates objectForKey:placementCode] vidcoinWillAppearForCustomEvent];
    [[self.delegates objectForKey:placementCode] vidcoinDidAppearForCustomEvent];
}

- (void)vidcoinViewDidDisappearWithViewInformation:(NSDictionary *)viewInfo {
    dontValidateView = NO;
    [self vidcoinDidValidateView:viewInfo];
    dontValidateView = YES;
    [[self.delegates objectForKey:[viewInfo objectForKey:kVCPlacementCode]] vidcoinWillDisappearForCustomEvent];
    [[self.delegates objectForKey:[viewInfo objectForKey:kVCPlacementCode]] vidcoinDidDisappearForCustomEvent];
    
    [self didUnloadAd:[viewInfo objectForKey:kVCPlacementCode]];
}

- (void)vidcoinDidValidateView:(NSDictionary *)viewInfo {
    if (dontValidateView) {
        return;
    }
    
    VCStatusCode statusCode = [[viewInfo objectForKey:kVCStatusCodeKey] integerValue];
    switch (statusCode) {
        case VCStatusCodeCancel: {
            break;
        }
        case VCStatusCodeError: {
            NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorUnknown userInfo:nil];
            [[self.delegates objectForKey:[viewInfo objectForKey:kVCPlacementCode]] vidcoinDidFailToPlayForCustomEvent:error];
            break;
        }
        case VCStatusCodeSuccess: {
            if ([[self.delegates objectForKey:[viewInfo objectForKey:kVCPlacementCode]] respondsToSelector:@selector(vidcoinShouldRewardUserForCustomEvent:)]) {
                NSNumber *reward = [viewInfo objectForKey:@"reward"];
                [[self.delegates objectForKey:[viewInfo objectForKey:kVCPlacementCode]] vidcoinShouldRewardUserForCustomEvent:reward];
            }
            break;
        }
        default: {
            NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorUnknown userInfo:nil];
            [[self.delegates objectForKey:[viewInfo objectForKey:kVCPlacementCode]] vidcoinDidFailToPlayForCustomEvent:error];
            break;
        }
    }
}
- (void)vidcoinDidReceiveTapEvent:(NSString*)placementCode {
      [[self.delegates objectForKey:placementCode] vidcoinDidReceiveTapEvent];
}

@end
