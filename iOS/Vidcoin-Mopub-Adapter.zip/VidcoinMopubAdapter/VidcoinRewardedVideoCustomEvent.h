//
//  VidcoinRewardedVideoCustomEvent.h
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import <Foundation/Foundation.h>

#if __has_include(<MoPub/MoPub.h>)
#import <MoPub/MoPub.h>
#else
#import "MoPub.h"
#import "MPRewardedVideoCustomEvent.h"
#endif

/*
 * Certified with version 1.4.1 of the Vidcoin SDK.
 */

@interface VidcoinRewardedVideoCustomEvent : MPRewardedVideoCustomEvent

@end
