//
//  VidcoinRewardedVideoCustomEvent.m
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import "VidcoinRewardedVideoCustomEvent.h"
#import "MPVidcoinRouter.h"
#import "MPRewardedVideoReward.h"
#import "VidcoinInstanceMediationSettings.h"

static NSString *const kMPVidcoinAppId = @"appId";
static NSString *const kMPVidcoinPlacementCode = @"placementCode";

@interface VidcoinRewardedVideoCustomEvent () <MPVidcoinRouterDelegate>

@end

@implementation VidcoinRewardedVideoCustomEvent

#pragma mark - MPRewardedVideoCustomEvent

- (void)requestRewardedVideoWithCustomEventInfo:(NSDictionary *)info {
    NSString *appId = [info objectForKey:kMPVidcoinAppId];
    NSString *placementCode = [info objectForKey:kMPVidcoinPlacementCode];
    
    VidcoinInstanceMediationSettings *instanceSettings = [self.delegate instanceMediationSettingsForClass:[VidcoinInstanceMediationSettings class]];
    VidcoinInstanceMediationSettings *globalSettings = [[MoPub sharedInstance] globalMediationSettingsForClass:[VidcoinInstanceMediationSettings class]];
    if (instanceSettings != nil) {
        [[MPVidcoinRouter sharedRouter] requestAdsWithAppId:appId placementCode:placementCode delegate:self settings:instanceSettings];
    } else if (globalSettings != nil) {
        [[MPVidcoinRouter sharedRouter] requestAdsWithAppId:appId placementCode:placementCode delegate:self settings:globalSettings];
    } else {
        [[MPVidcoinRouter sharedRouter] requestAdsWithAppId:appId placementCode:placementCode delegate:self settings:nil];
    }
    
}

- (BOOL)hasAdAvailable {
    return [[MPVidcoinRouter sharedRouter] adAvailable];
}

- (void)presentRewardedVideoFromViewController:(UIViewController *)viewController {
    [[MPVidcoinRouter sharedRouter] presentRewardedVideoAdFromViewController:viewController];
}

#pragma mark - MPVidcoinRouterDelegate

- (void)vidcoinDidLoadAdForCustomEvent {
    [self.delegate rewardedVideoDidLoadAdForCustomEvent:self];
}

- (void)vidcoinDidFailToLoadAdForCustomEvent:(NSError *)error {
    [self.delegate rewardedVideoDidFailToLoadAdForCustomEvent:self error:error];
}

- (void)vidcoinDidFailToPlayForCustomEvent:(NSError *)error {
    [self.delegate rewardedVideoDidFailToPlayForCustomEvent:self error:error];
}

- (void)vidcoinWillAppearForCustomEvent {
    [self.delegate rewardedVideoWillAppearForCustomEvent:self];
}

- (void)vidcoinDidAppearForCustomEvent {
    [self.delegate rewardedVideoDidAppearForCustomEvent:self];
}

- (void)vidcoinWillDisappearForCustomEvent {
    [self.delegate rewardedVideoWillDisappearForCustomEvent:self];
}

- (void)vidcoinDidDisappearForCustomEvent {
    [self.delegate rewardedVideoDidDisappearForCustomEvent:self];
}

- (void)vidcoinShouldRewardUserForCustomEvent:(NSNumber *)reward {
    NSString *currencyType = kMPRewardedVideoRewardCurrencyTypeUnspecified;
    MPRewardedVideoReward *videoReward = [[MPRewardedVideoReward alloc] initWithCurrencyType:currencyType amount:reward];
    [self.delegate rewardedVideoShouldRewardUserForCustomEvent:self reward:videoReward];
}

@end
