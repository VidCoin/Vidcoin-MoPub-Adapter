//
//  MPVidcoinRouter.h
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <VidCoin/VidCoin.h>

@protocol MPVidcoinRouterDelegate;
@class VidcoinInstanceMediationSettings;

@interface MPVidcoinRouter : NSObject <VidCoinDelegate>

@property (nonatomic, weak) id<MPVidcoinRouterDelegate> delegate;

+ (MPVidcoinRouter *)sharedRouter;

- (void)requestAdsWithAppId:(NSString *)appId placementCode:(NSString *)placementCode delegate:(id<MPVidcoinRouterDelegate>)delegate settings:(VidcoinInstanceMediationSettings *)settings;
- (BOOL)adAvailable;
- (void)presentRewardedVideoAdFromViewController:(UIViewController *)viewController;

@end

@protocol MPVidcoinRouterDelegate <NSObject>
@required

- (void)vidcoinDidLoadAdForCustomEvent;
- (void)vidcoinDidFailToLoadAdForCustomEvent:(NSError *)error;
- (void)vidcoinDidFailToPlayForCustomEvent:(NSError *)error;
- (void)vidcoinWillAppearForCustomEvent;
- (void)vidcoinDidAppearForCustomEvent;
- (void)vidcoinWillDisappearForCustomEvent;
- (void)vidcoinDidDisappearForCustomEvent;
- (void)vidcoinShouldRewardUserForCustomEvent:(NSNumber *)reward;

@end
