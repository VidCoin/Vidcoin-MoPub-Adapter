//
//  MPInstanceProvider+Vidcoin.m
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import "MPInstanceProvider+Vidcoin.h"
#import "MPVidcoinRouter.h"

@implementation MPInstanceProvider (Vidcoin)

- (MPVidcoinRouter *)sharedMPVidcoinRouter {
    return [self singletonForClass:[MPVidcoinRouter class]
                          provider:^id{
                              return [[MPVidcoinRouter alloc] init];
                          }];
}

@end
