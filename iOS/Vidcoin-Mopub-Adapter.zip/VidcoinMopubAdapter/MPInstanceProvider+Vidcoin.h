//
//  MPInstanceProvider+Vidcoin.h
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#if __has_include(<MoPub/MoPub.h>)
#import <MoPub/MoPub.h>
#else
#import "MPInstanceProvider.h"
#endif

@class MPVidcoinRouter;

@interface MPInstanceProvider (Vidcoin)

- (MPVidcoinRouter *)sharedMPVidcoinRouter;

@end
