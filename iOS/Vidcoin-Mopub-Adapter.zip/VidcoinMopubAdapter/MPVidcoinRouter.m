//
//  MPVidcoinRouter.m
//  MopubAdapter
//
//  Copyright © 2016 Vidcoin. All rights reserved.
//

#import "MPVidcoinRouter.h"
#import "MPInstanceProvider+Vidcoin.h"
#import "MPRewardedVideoError.h"
#import "MPLogging.h"
#import "VidcoinInstanceMediationSettings.h"

@implementation MPVidcoinRouter {
    NSString* placementCode;
    BOOL initialized;
}

#pragma mark - Public methods

+ (MPVidcoinRouter *)sharedRouter {
    return [[MPInstanceProvider sharedProvider] sharedMPVidcoinRouter];
}

- (void)requestAdsWithAppId:(NSString *)appId placementCode:(NSString *)placement delegate:(id<MPVidcoinRouterDelegate>)delegate settings:(VidcoinInstanceMediationSettings *)settings {
    if (!initialized) {
        self.delegate = delegate;
        [self startWithAppId:appId placementCode:placement];
        
        if (settings != nil) {
            NSMutableDictionary *vidcoinDictionary = [NSMutableDictionary dictionary];
            if (settings.userAppId && ![settings.userAppId isEqualToString:@""]) {
                [vidcoinDictionary setObject:settings.userAppId forKey:kVCUserGameID];
            }
            if (settings.userBithYear && ![settings.userBithYear isEqualToString:@""]) {
                [vidcoinDictionary setObject:settings.userBithYear forKey:kVCUserBirthYear];
            }
            if (settings.userGender && ![settings.userGender isEqualToString:@""]) {
                [vidcoinDictionary setObject:settings.userGender forKey:kVCUserGenderKey];
            }
            
            if (vidcoinDictionary && vidcoinDictionary.count > 0) {
                [VidCoin updateUserDictionary:[vidcoinDictionary copy]];
            }
        }
        
        initialized = YES;
    }
    
    if ([self adAvailable]) {
        [self.delegate vidcoinDidLoadAdForCustomEvent];
    }
}

- (BOOL)adAvailable {
    return (placementCode == nil || [placementCode isEqualToString:@""]) ? NO : [VidCoin videoIsAvailableForPlacement:placementCode];
}

- (void)presentRewardedVideoAdFromViewController:(UIViewController *)viewController {
    if ([self adAvailable]) {
        [VidCoin playAdFromViewController:viewController forPlacement:placementCode animated:YES];
    } else {
        MPLogInfo(@"Failed to present Vidcoin video ad: no ad available.");
        NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorNoAdsAvailable userInfo:nil];
        [self.delegate vidcoinDidFailToPlayForCustomEvent:error];
    }
}

#pragma mark - Private methods
- (id)init {
    self = [super init];
    if (self) {
        placementCode = @"";
        initialized = NO;
    }
    return self;
}

- (void)startWithAppId:(NSString*)appId placementCode:(NSString*)placement {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        [VidCoin startWithGameId:appId delegate:self];
        [VidCoin setLoggingEnabled:YES];
        placementCode = placement;
    });
}

#pragma mark - VidCoinDelegate

- (void)vidcoinCampaignsUpdate {
    if ([self adAvailable]) {
        [self.delegate vidcoinDidLoadAdForCustomEvent];
    }
}

- (void)vidcoinViewWillAppear {
    [self.delegate vidcoinWillAppearForCustomEvent];
    [self.delegate vidcoinDidAppearForCustomEvent];
}

- (void)vidcoinViewDidDisappearWithViewInformation:(NSDictionary *)viewInfo {
    [self.delegate vidcoinWillDisappearForCustomEvent];
    [self.delegate vidcoinDidDisappearForCustomEvent];
}

- (void)vidcoinDidValidateView:(NSDictionary *)viewInfo {
    VCStatusCode statusCode = [[viewInfo objectForKey:@"statusCode"] integerValue];
    switch (statusCode) {
        case VCStatusCodeCancel: {
            break;
        }
        case VCStatusCodeError: {
            NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorUnknown userInfo:nil];
            [self.delegate vidcoinDidFailToPlayForCustomEvent:error];
            break;
        }
        case VCStatusCodeSuccess: {
            NSNumber *reward = [viewInfo objectForKey:@"reward"];
            [self.delegate vidcoinShouldRewardUserForCustomEvent:reward];
            break;
        }
        default: {
            NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain code:MPRewardedVideoAdErrorUnknown userInfo:nil];
            [self.delegate vidcoinDidFailToPlayForCustomEvent:error];
            break;
        }
    }

}

@end
