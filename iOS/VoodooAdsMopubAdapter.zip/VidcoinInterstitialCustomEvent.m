//
//  VidcoinInterstitialCustomEvent.m
//  MoPubSDK
//
//  Copyright © 2019 MoPub. All rights reserved.
//

#import "VidcoinInterstitialCustomEvent.h"

@implementation VidcoinInterstitialCustomEvent
 
@end
