//
//  VidcoinInterstitialCustomEvent.h
//  MoPubSDKFramework
//
//  Copyright © 2019 MoPub. All rights reserved.
//

#import "VAInterstitialCustomEvent.h"

@interface VidcoinInterstitialCustomEvent : VAInterstitialCustomEvent

@end
