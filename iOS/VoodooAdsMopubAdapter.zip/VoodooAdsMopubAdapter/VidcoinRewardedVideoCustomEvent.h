//
//  VidcoinRewardedVideoCustomEvent.h
//  MoPubSDK
//
//  Copyright © 2019 MoPub. All rights reserved.
//
#import "VARewardedCustomEvent.h"

@interface VidcoinRewardedVideoCustomEvent : VARewardedCustomEvent

@end


