//
//  VidcoinRewardedVideoCustomEvent.m
//  MoPubSDK
//
//  Copyright © 2019 MoPub. All rights reserved.
//

#import "VidcoinRewardedVideoCustomEvent.h"

@implementation VidcoinRewardedVideoCustomEvent

@end
