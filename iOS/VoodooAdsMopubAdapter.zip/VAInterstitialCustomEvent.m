//
//  VAInterstitialCustomEvent.m
//  MoPubSDK
//
//  Copyright © 2019 MoPub. All rights reserved.
//

#import "VAInterstitialCustomEvent.h"
static NSString *const kMPVoodooAdsZoneId = @"zoneId";

@interface VAInterstitialCustomEvent ()

@property (nonatomic, nonnull, strong) VAInterstitialManager *manager;

@end

@implementation VAInterstitialCustomEvent

#pragma mark - MPInterstitialCustomEvent

- (void)requestInterstitialWithCustomEventInfo:(NSDictionary *)info {
    [self.manager requestWithZoneId:[info objectForKey:kMPVoodooAdsZoneId]];
}

- (void)showInterstitialFromRootViewController:(UIViewController *)rootViewController {
    [self.manager showFromViewController:rootViewController
                                animated:YES];
}

#pragma mark - Properties

-(VAInterstitialManager *)manager {
    if (!_manager) {
        BOOL isGDPRApplicable = ([[MoPub sharedInstance] isGDPRApplicable] != MPBoolNo);
        BOOL hasConsent = [[MoPub sharedInstance] canCollectPersonalInfo];
        
        _manager = [[VAInterstitialManager alloc] initWithConsent:hasConsent
                                                             isGDPRApplicable:isGDPRApplicable
                                                                     delegate:self];
    }
    return _manager;
}

#pragma mark - VAManagerDelegate

- (void)adRequestFinished:(VAManager *)manager {
    [self.delegate interstitialCustomEvent:self didLoadAd:nil];
}
- (void)adRequestFailed:(VAManager *)manager {
    [self.delegate interstitialCustomEvent:self
                  didFailToLoadAdWithError:[NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain
                                                               code:MPRewardedVideoAdErrorNoAdsAvailable
                                                           userInfo:nil]];
}

- (void)adDidReceiveTap:(VAManager *)manager {
    [self.delegate interstitialCustomEventDidReceiveTapEvent:self];
}

- (void)adViewWillAppear:(VAManager *)manager {
    [self.delegate interstitialCustomEventWillAppear:self];
}

- (void)adViewDidAppear:(VAManager *)manager {
    [self.delegate interstitialCustomEventDidAppear:self];
}

- (void)adView:(VAManager *)manager didDisappearWithStatus:(VCStatusCode)status {
    [self.delegate interstitialCustomEventDidDisappear:self];
}

- (void)adView:(VAManager *)manager willDisappearWithStatus:(VCStatusCode)status {
    [self.delegate interstitialCustomEventWillDisappear:self];
}

@end
