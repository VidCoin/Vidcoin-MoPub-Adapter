//
//  VARewardedCustomEvent.h
//  MoPubSDK
//
//  Copyright © 2019 MoPub. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <VoodooAds/VoodooAds.h>

#if __has_include(<MoPub/MoPub.h>)
#import <MoPub/MoPub.h>
#elif __has_include(<MoPubSDKFramework/MoPub.h>)
#import <MoPubSDKFramework/MoPub.h>
#else
#import "MPRewardedVideoCustomEvent.h"
#endif

@interface VARewardedCustomEvent : MPRewardedVideoCustomEvent <VAManagerDelegate>
 
@end
