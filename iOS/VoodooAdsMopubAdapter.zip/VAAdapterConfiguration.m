//
//  VAAdapterConfiguration.m
//  MoPubSDK
//
//  Created by sarra_srairi on 30/04/2019.
//  Copyright © 2019 MoPub. All rights reserved.
//

#import "VAAdapterConfiguration.h"
#import <VoodooAds/VoodooAds.h>

@implementation VAAdapterConfiguration

- (NSString *)adapterVersion {
    return VAManager.sdkVersion;
}

- (NSString *)moPubNetworkName {
    return VAManager.sdkName;
}

- (NSString *)networkSdkVersion {
    return VAManager.sdkVersion;
}
    
- (NSString *)biddingToken {
    return nil;
}

- (void)initializeNetworkWithConfiguration:(NSDictionary<NSString *, id> *)configuration
                                  complete:(void(^)(NSError *))complete {
    // Nothing to initialize; complete immediately
    if (complete != nil) {
        complete(nil);
    }
    
    [VAManager setLoggingEnabled:MPLogging.consoleLogLevel != MPLogLevelNone];
}

@end
