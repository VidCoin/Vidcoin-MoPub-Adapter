//
//  VARewardedCustomEvent.m
//  MoPubSDK
//
//  Copyright © 2019 MoPub. All rights reserved.
//

#import "VARewardedCustomEvent.h"

static NSString *const kMPVoodooAdsZoneId = @"zoneId";

@interface VARewardedCustomEvent ()

@property (nonatomic, nonnull, strong) VARewardedManager *manager;

@end

@implementation VARewardedCustomEvent

#pragma mark - MPInterstitialCustomEvent

- (BOOL)hasAdAvailable {
    return self.manager.isAdAvailable;
}

- (void)requestRewardedVideoWithCustomEventInfo:(NSDictionary *)info {
    [self.manager requestWithZoneId:[info objectForKey:kMPVoodooAdsZoneId]];
}

- (void)presentRewardedVideoFromViewController:(UIViewController *)viewController {
    [self.manager showFromViewController:viewController
                                animated:YES];
}

#pragma mark - Properties

- (VARewardedManager *)manager {
    if (!_manager) {
        BOOL isGDPRApplicable = ([[MoPub sharedInstance] isGDPRApplicable] != MPBoolNo);
        BOOL hasConsent = [[MoPub sharedInstance] canCollectPersonalInfo];
        
        _manager = [[VARewardedManager alloc] initWithConsent:hasConsent
                                             isGDPRApplicable:isGDPRApplicable
                                                     delegate:self];
    }
    return _manager;
}

#pragma mark - VAManagerDelegate

- (void)adRequestFinished:(VAManager *)manager {
    [self.delegate rewardedVideoDidLoadAdForCustomEvent:self];
}

- (void)adRequestFailed:(VAManager *)manager {
    [self.delegate rewardedVideoDidFailToLoadAdForCustomEvent:self
                                                        error:[NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain
                                                                                  code:MPRewardedVideoAdErrorNoAdsAvailable
                                                                              userInfo:nil]];
}

- (void)adDidReceiveTap:(VAManager *)manager {
    [self.delegate rewardedVideoDidReceiveTapEventForCustomEvent:self];
}

- (void)adViewWillAppear:(VAManager *)manager {
    [self.delegate rewardedVideoWillAppearForCustomEvent:self];
}

- (void)adViewDidAppear:(VAManager *)manager {
    [self.delegate rewardedVideoDidAppearForCustomEvent:self];
}

- (void)adView:(VAManager *)manager didDisappearWithStatus:(VCStatusCode)status {
    switch (status) {
        case VCStatusCodeError: {
            NSError *error = [NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain
                                                 code:MPRewardedVideoAdErrorUnknown
                                             userInfo:nil];
            [self.delegate rewardedVideoDidFailToPlayForCustomEvent:self error:error];
            break;
        }
        case VCStatusCodeSuccess: {
            NSString *currencyType = kMPRewardedVideoRewardCurrencyTypeUnspecified;
            MPRewardedVideoReward *videoReward = [[MPRewardedVideoReward alloc] initWithCurrencyType:currencyType
                                                                                              amount:@0];
            [self.delegate rewardedVideoShouldRewardUserForCustomEvent:self reward:videoReward];
            break;
        }
    }
    [self.delegate rewardedVideoDidDisappearForCustomEvent:self];
}

- (void)adView:(VAManager *)manager willDisappearWithStatus:(VCStatusCode)status {
    [self.delegate rewardedVideoWillDisappearForCustomEvent:self];
}

@end
