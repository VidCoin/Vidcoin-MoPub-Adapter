//
//  VABannerCustomEvent.m
//  MoPubSDK
//
//  Copyright © 2019 MoPub. All rights reserved.
//

#import "VABannerCustomEvent.h"

static NSString *const kMPVoodooAdsZoneId = @"zoneId";

@interface VABannerCustomEvent ()

@property (nonatomic, nonnull, strong) VABannerManager *manager;

@end

@implementation VABannerCustomEvent {
    CGSize bannerSize;
}


- (void)requestAdWithSize:(CGSize)size customEventInfo:(NSDictionary *)info {
    bannerSize = size;
    NSString *zoneId = [info objectForKey:kMPVoodooAdsZoneId];
    
    [self.manager requestWithZoneId:zoneId];
}

#pragma mark - Properties

- (VABannerManager *)manager {
    if (!_manager) {
        BOOL isGDPRApplicable = ([[MoPub sharedInstance] isGDPRApplicable] != MPBoolNo);
        BOOL hasConsent = [[MoPub sharedInstance] canCollectPersonalInfo];
        
        _manager = [[VABannerManager alloc] initWithConsent:hasConsent
                                           isGDPRApplicable:isGDPRApplicable
                                                   delegate:self];
    }
    return _manager;
}

#pragma mark - VAManagerDelegate

- (void)adRequestFinished:(VAManager *)manager {
    [manager showFromViewController:nil animated:NO];
}

- (void)adRequestFailed:(VAManager *)manager {
    [self.delegate bannerCustomEvent:self
            didFailToLoadAdWithError:[NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain
                                                         code:MPRewardedVideoAdErrorNoAdsAvailable
                                                     userInfo:nil]];
}

- (void)adDidReceiveTap:(VAManager *)manager {
    [self.delegate trackClick];
    [self.delegate bannerCustomEventWillBeginAction:self];
}

- (void)adView:(nonnull VAManager *)manager didDisappearWithStatus:(VCStatusCode)status {
    [self.delegate bannerCustomEventDidFinishAction:self];
}

#pragma mark - VABannerManagerDelegate

- (void)managerDidFailToLoadBanner:(nonnull VAManager *)manager {
    [self.delegate bannerCustomEvent:self
            didFailToLoadAdWithError:[NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain
                                                         code:MPRewardedVideoAdErrorNoAdsAvailable
                                                     userInfo:nil]];
}

- (void)manager:(nonnull VAManager *)manager didLoadBanner:(nonnull UIView *)bannerView {
    
    if (manager.isAdAvailable) {
        bannerView.frame = CGRectMake(0, 0, bannerSize.width, bannerSize.height);
        [self.delegate bannerCustomEvent:self didLoadAd:bannerView];
    } else {
        [self.delegate bannerCustomEvent:self
                didFailToLoadAdWithError:[NSError errorWithDomain:MoPubRewardedVideoAdsSDKDomain
                                                             code:MPRewardedVideoAdErrorNoAdsAvailable
                                                         userInfo:nil]];
    }
}

@end
